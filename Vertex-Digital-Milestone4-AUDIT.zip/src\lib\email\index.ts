import type { EmailProvider } from "@/lib/email/provider";
import { ResendEmailProvider } from "@/lib/email/resend-provider";
import { ConsoleEmailProvider } from "@/lib/email/console-provider";

let providerInstance: EmailProvider | null = null;

export function getEmailProvider(): EmailProvider {
  if (providerInstance) return providerInstance;

  const apiKey = process.env.RESEND_API_KEY;
  const fromAddress = process.env.EMAIL_FROM;

  if (apiKey && fromAddress) {
    providerInstance = new ResendEmailProvider(apiKey, fromAddress);
  } else {
    if (process.env.NODE_ENV !== "production") {
      console.warn(
        "[email] RESEND_API_KEY / EMAIL_FROM not set — emails will be logged, " +
          "not sent. See README > Email setup."
      );
    }
    providerInstance = new ConsoleEmailProvider();
  }

  return providerInstance;
}
